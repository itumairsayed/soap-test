package com.example.axis.service;

public class HelloWorldService {
    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }
}
